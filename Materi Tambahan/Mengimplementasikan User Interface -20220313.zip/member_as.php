<?php

	//array barang
	//array asosiatif isinya merk coach, guess, zara, dengan masing2 harganya
$barang = array ("Guess"=>1500000, "Zara"=>1000000, "Coach"=>2000000); 

	//	Menghitung harga barang (tas)
function hitungBarang($barang, $merk){
	$hargaBarang = $barang[$merk];
	return $hargaBarang;
}

//	Menghitung total harga barang yang dikalikan dengan jumlah
function totalHarga($barang, $merk, $jumlah){
	$hargaBarang = hitungBarang($barang, $merk);
	$totalHarga = $hargaBarang  * $jumlah;
	return $totalHarga;
}

//	Array jenis tas
$jenis = ["Sling Bag", "Hand Bag","Tote Bag", "Ransel", "Clutch"];

//	Mengurutkan array
sort($jenis);
?>

<!DOCTYPE html>
<html>
<head>
	<title>Toko Bag-Bag</title>
	<!-- Memanggil CSS. -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
	
	<h3>Perhitungan Harga Tas Toko Bag-Bag</h3>
	<!-- Form untuk memasukkan data pelanggan. -->
	<table style="width:100%">
		<form action="" method="post" id="formTagihan">
			<tr>
				<!-- nomor transaksi -->
				<td><label for="nomor">Nomor Transaksi:</label></td>
				<td><input type="number" id="nomor" name="nomor"></td>
			</tr>
			<tr>
				<!-- Masukan data jenis. -->
				<td><label for="jenis">Jenis Tas:</label></td>
				<td><select id="jenis" name="jenis">
					<option value="">- Jenis Tas -</option>
					<?php

					foreach ($jenis as $jenisTas) {
						echo "<option value=".$jenisTas.">".$jenisTas."</option>";
					}
					?>	
				</select></td>
			</tr>
			<tr>
				<!-- merk -->
				<td><label for="merk">Pilih Merk:</label></td>
				<td><select name="merk" id="merk">
					<option>- Pilihan -</option>
					<option value="Guess">Guess</option>
					<option value="Zara">Zara</option>
					<option value="Coach">Coach</option>
				</select></td>
			</tr>
			<tr>
				<!-- Jumlah Barang -->
				<td><label for="nomor">Jumlah Barang:</label></td>
				<td><input type="number" id="jumlah" name="jumlah"></td>
			</tr>
			<tr>
				<!-- Tombol Hitung/Submit -->
				<td><button type="submit" form="formTagihan" value="Hitung" name="Hitung" class="btn btn-primary">Hitung</button></td>
				<td></td>
			</tr>
		</form>
	</table>

	<p><br><br>


		<?php
		if(isset($_POST['Hitung'])) {
			$jumlah = $_POST['jumlah'];

				//	Memanggil fungsi totalHarga untuk ditampilkan pada tabel
			$bill = totalHarga($barang,$_POST['merk'], $jumlah);

				//	Menampilkan bill
			echo "
			<table style='width:500px' class='table table-success table-striped'>
			<tr>
			<!-- Menampilkan Nomor Transaksi -->
			<td>Nomor Transaksi:</td>
			<td>".$_POST['nomor']."</td>
			</tr>
			<tr>
			<!-- Menampilkan Jenis Tas -->
			<td>Jenis Tas:</td>
			<td>".$_POST['jenis']."</td>
			</tr>
			<tr>
			<!-- Menampilkan Merk Barang -->
			<td>Merk Barang:</td>
			<td>".$_POST['merk']."</td>
			</tr>
			<tr>
			<!-- Menampilkan Harga Barang -->
			<td>Harga Barang:</td>
			<td>Rp ".number_format(hitungBarang($barang, $_POST['merk']), 0, ".", ".").",-</td>
			</tr>
			<tr>
			<!-- Menampilkan Jumlah Barang -->
			<td>Jumlah Barang:</td>
			<td>".$_POST['jumlah']."</td>
			</tr>
			<tr>
			<!-- Menampilkan Total Harga -->
			<td>Total Harga:</td>
			<td>Rp ".number_format($bill, 0, ",", ",").",-</td>
			</tr>
			</table>
			";
		}
		?>

	</body>
	</html>