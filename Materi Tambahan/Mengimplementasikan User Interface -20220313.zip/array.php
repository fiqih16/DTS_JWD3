<!DOCTYPE html>
<html>
<head>
	<title>Latihan Array</title>
</head>
<body>
	<?php
	//array 1 dimensi
	$peserta = ["Rinvilda", "Prima", "Ahmad", "Yazid", "Rachma"];
	// $peserta = array("Rinvilda", "Prima", "Ahmad", "Yazid", "Rachma");

	sort($peserta);
	?>

	<form action="" method="post" id="array">
		<tr>
			<td><label for="peserta">Daftar Peserta: </label></td>
			<td><select id="peserta" name="peserta">
				<option value=""> Peserta </option>
				<?php
				// Menampilkan pilihan (dropdown) nama peserta
				foreach ($peserta as $nama) {
					echo "<option value=".$nama.">".$nama."</option>";
				}
				?>	
			</select></td>
		</tr>

		<tr>
			<td><button type="submit" form="array" value="kirim" name="kirim">kirim</button></td>
			<td></td>
		</tr>
	</form>

	<?php
	if(isset($_POST['kirim'])) {
		echo "
		<br>
		<table style='width:300px' border='1'>
		<tr>
		<td>Nama Peserta:</td>
		<td>".$_POST['peserta']."</td>
		</tr>"
		;
	}
	?>

</body>
</html>