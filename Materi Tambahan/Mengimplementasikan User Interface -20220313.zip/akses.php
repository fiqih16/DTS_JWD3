<?php  
 $file = fopen("agung.txt","w");   //membuat file txt dan membuat mode w = write
 fwrite($file,"Halo, ini Agung Peserta JWD1");  // menuliskan isi file
 fclose($file);  
 ?>  